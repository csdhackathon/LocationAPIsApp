package com.pb.locationapis.parser;

/**
 * Created by NEX7IMH on 19-June-17.
 */
public enum ParserType {
    PARSER_GET_ROUTE_FOR_AN_AGENT
}
